(function(){

  var t = {
    playlist: [
      {
        file: "resources/tracks/01.mp3",
        thumb: "resources/thumbs/01.jpg",
        trackName: "Pizza",
        trackArtist: "Fd& Alan Walker",
        trackAlbum: "Single",
      },
      {
        file: "resources/tracks/02.mp3",
        thumb: "resources/thumbs/02.gif",
        trackName: "Electromania - Shine On",
        trackArtist: "Electró",
        trackAlbum: "Single",
      },
      {
        file: "resources/tracks/03.mp3",
        thumb: "resources/thumbs/02.gif",
        trackName: "Happy lyfe",
        trackArtist: "Electro walker",
        trackAlbum: "Single",
      },
      {
        file: "resources/tracks/03.mp3",
        thumb: "resources/thumbs/03.jpg",
        trackName: "MuraD - flame",
        trackArtist: "Alan Walker",
        trackAlbum: "Single",
      }
    ]
  }

  $(".jAudio").jAudio(t);

})();